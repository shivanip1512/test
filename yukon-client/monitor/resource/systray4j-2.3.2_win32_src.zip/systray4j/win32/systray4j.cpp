/*********************************************************************************
                                   systray4j.cpp
                                   -------------
    author               : Tamas Bara
    copyright            : (C) 2002-2003 by SnoozeSoft
    email                : snoozesoft@compuserve.de
 *********************************************************************************/

/*********************************************************************************
 *                                                                               *
 *   This library is free software; you can redistribute it and/or               *
 *   modify it under the terms of the GNU Lesser General Public                  *
 *   License as published by the Free Software Foundation; either                *
 *   version 2.1 of the License, or (at your option) any later version.          *
 *                                                                               *
 *   This library is distributed in the hope that it will be useful,             *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU           *
 *   Lesser General Public License for more details.                             *
 *                                                                               *
 *   You should have received a copy of the GNU Lesser General Public            *
 *   License along with this library; if not, write to the Free Software         *
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA   *
 *                                                                               *
 *********************************************************************************/

#include "stdafx.h"
#include "systray4j.h"
#include "systraymanager.h"

HINSTANCE g_instance = 0;
bool managerInitialized = false;

// UTF8 to ASCII converter
char* utf8ToAscii( LPCTSTR utf8 );

// entry and exit point
BOOL APIENTRY DllMain( HINSTANCE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved )
{
    if( ul_reason_for_call == DLL_PROCESS_ATTACH ) g_instance = hModule;
    else if( ul_reason_for_call == DLL_PROCESS_DETACH ) SysTrayManager::destroy();

    return TRUE;
}

// add a new icon to the system tray, create the associated menu and return
// the its id
JNIEXPORT jint JNICALL
Java_snoozesoft_systray4j_Win32SysTray_addMainMenuNative( JNIEnv* pEnv,
                                                          jobject obj,
                                                          jobject menuObj,
                                                          jstring iconFileName,
                                                          jstring toolTip )
{
    if( !managerInitialized )
    {
        // this happens if this is the first time this function is called
        SysTrayManager::init( g_instance, pEnv );
        managerInitialized = true;
    }
    
    jboolean isCopy;
    // extract the tooltip and the file name
    LPCTSTR tip = pEnv->GetStringUTFChars( toolTip, &isCopy );
    LPCTSTR fileName = pEnv->GetStringUTFChars( iconFileName, &isCopy );

    char* tipAscii = utf8ToAscii( tip );

    // pass all data to the manager and receive the assigned menu id
    UINT id = SysTrayManager::addMainMenu( menuObj, fileName, tipAscii );

    // clean up
    pEnv->ReleaseStringUTFChars( iconFileName, fileName );
    pEnv->ReleaseStringUTFChars( toolTip, tip );
    delete [] tipAscii;

    return id;
}

// create a new submenu and return its id 
JNIEXPORT jint JNICALL
Java_snoozesoft_systray4j_Win32SysTray_addSubMenuNative( JNIEnv* pEnv,
                                                         jobject obj,
                                                         jobject menuObj )
{
    if( !managerInitialized )
    {
        // this happens if this is the first time this function is called
        SysTrayManager::init( g_instance, pEnv );
        managerInitialized = true;
    }
    
    // pass the menu object and receive the assigned menu id
    UINT id = SysTrayManager::addSubMenu( menuObj );

    return id;
}

// change the tooltip displayed over the icon
JNIEXPORT void JNICALL
Java_snoozesoft_systray4j_Win32SysTray_setToolTipNative( JNIEnv* pEnv,
                                                         jobject obj,
                                                         jint menuId,
                                                         jstring toolTip )
{
    jboolean isCopy;
    LPCTSTR tip = pEnv->GetStringUTFChars( toolTip, &isCopy );

    char* tipAscii = utf8ToAscii( tip );
    SysTrayManager::setToolTip( menuId, tipAscii ); 
    
    pEnv->ReleaseStringUTFChars( toolTip, tip );
    delete [] tipAscii;
}

// show/hide the icon in the system tray
JNIEXPORT void JNICALL
Java_snoozesoft_systray4j_Win32SysTray_showIconNative( JNIEnv* pEnv,
                                                       jobject obj,
                                                       jint menuId,
                                                       jboolean show )
{
    SysTrayManager::showIcon( menuId, show );
}

// change the icon shown in the system tray
JNIEXPORT void JNICALL
Java_snoozesoft_systray4j_Win32SysTray_setIconNative( JNIEnv* pEnv,
                                                      jobject obj,
                                                      jint menuId,
                                                      jstring iconFileName )
{
    jboolean isCopy;
    LPCTSTR fileName = pEnv->GetStringUTFChars( iconFileName, &isCopy );
    SysTrayManager::setIcon( menuId, fileName ); 
    pEnv->ReleaseStringUTFChars( iconFileName, fileName );
}

// enable/disable an item
JNIEXPORT void JNICALL
Java_snoozesoft_systray4j_Win32SysTray_enableItemNative( JNIEnv* pEnv,
                                                         jobject obj,
                                                         jint menuId,
                                                         jint itemIndex,
                                                         jboolean enable )
{
    SysTrayManager::enableItem( menuId, itemIndex, enable );
}

JNIEXPORT void JNICALL
Java_snoozesoft_systray4j_Win32SysTray_checkItemNative( JNIEnv* pEnv,
                                                        jobject obj,
                                                        jint menuId,
                                                        jint itemIndex,
                                                        jboolean check )
{
    SysTrayManager::checkItem( menuId, itemIndex, check );
}

// change the label of the specified item
JNIEXPORT void JNICALL
Java_snoozesoft_systray4j_Win32SysTray_setItemLabelNative( JNIEnv* pEnv,
                                                          jobject obj,
                                                          jint menuId,
                                                          jint itemIndex,
                                                          jstring itemLabel )
{
    jboolean isCopy;
    LPCTSTR label = pEnv->GetStringUTFChars( itemLabel, &isCopy );

    char* labelAscii = utf8ToAscii( label );
    SysTrayManager::setItemLabel( menuId, itemIndex, labelAscii );

    pEnv->ReleaseStringUTFChars( itemLabel, label );
    delete [] labelAscii;
}

// insert an item to the menu at the specified position
JNIEXPORT void JNICALL
Java_snoozesoft_systray4j_Win32SysTray_addItemNative( JNIEnv* pEnv,
                                                      jobject obj,
                                                      jint menuId,
                                                      jint itemIndex,
                                                      jstring itemLabel,
                                                      jboolean checkable,
                                                      jboolean checked,
                                                      jboolean enabled )
{
    jboolean isCopy;
    LPCTSTR label = pEnv->GetStringUTFChars( itemLabel, &isCopy );

    char* labelAscii = utf8ToAscii( label );
    SysTrayManager::addItem( menuId, itemIndex, labelAscii, checkable, checked, enabled ); 
    
    pEnv->ReleaseStringUTFChars( itemLabel, label );
    delete [] labelAscii;
}

// remove the specified item from the menu
JNIEXPORT void JNICALL
Java_snoozesoft_systray4j_Win32SysTray_removeItemNative( JNIEnv* pEnv,
                                                         jobject obj,
                                                         jint menuId,
                                                         jint itemIndex )
{
    SysTrayManager::removeItem( menuId, itemIndex );
}

// change the whole menu by replacing all items
JNIEXPORT void JNICALL
Java_snoozesoft_systray4j_Win32SysTray_removeAllNative( JNIEnv* pEnv,
                                                        jobject obj,
                                                        jint menuId )
{
    // forward the call
    SysTrayManager::removeAll( menuId );
}

// detach our thread from the JVM
JNIEXPORT void JNICALL
Java_snoozesoft_systray4j_Win32SysTray_disposeNative( JNIEnv* pEnv, jclass clazz )
{
    SysTrayManager::dispose();
}

char* utf8ToAscii( LPCTSTR utf8 )
{
    int code, i = 0;
    char* buffer = new char[ strlen( utf8 ) + 1 ];
    for( LPCTSTR iterator = utf8; *iterator != '\0'; iterator++, i++ )
    {
        if( *iterator > 0 ) buffer[ i ] = *iterator;
        else
        {
            code = ( ( *iterator & 0x1f ) << 6 ) + ( *( iterator + 1 ) & 0x3f );
            buffer[ i ] = code - 256;
            iterator++;
        }
    }

    buffer[ i ] = 0;

    return buffer;
}
