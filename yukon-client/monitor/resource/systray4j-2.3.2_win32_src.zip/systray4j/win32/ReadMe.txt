
SysTray for Java v2.3.2 (win32)

additional include paths:
    <JAVA_SDK_HOME>\include
    <JAVA_SDK_HOME>\include\win32