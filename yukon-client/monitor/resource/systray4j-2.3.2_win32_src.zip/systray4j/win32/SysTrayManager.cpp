/*********************************************************************************
                                 SysTrayManager.cpp
                                 ------------------
    author               : Tamas Bara
    copyright            : (C) 2002-2003 by SnoozeSoft
    email                : snoozesoft@compuserve.de
 *********************************************************************************/

/*********************************************************************************
 *                                                                               *
 *   This library is free software; you can redistribute it and/or               *
 *   modify it under the terms of the GNU Lesser General Public                  *
 *   License as published by the Free Software Foundation; either                *
 *   version 2.1 of the License, or (at your option) any later version.          *
 *                                                                               *
 *   This library is distributed in the hope that it will be useful,             *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU           *
 *   Lesser General Public License for more details.                             *
 *                                                                               *
 *   You should have received a copy of the GNU Lesser General Public            *
 *   License along with this library; if not, write to the Free Software         *
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA   *
 *                                                                               *
 *********************************************************************************/

#include "resource.h"
#include "StdAfx.h"
#include "systraymanager.h"

// the id of our thread
DWORD SysTrayManager::s_threadId                                    = 0;

// instance handle
HINSTANCE SysTrayManager::s_hInstance                               = 0;

// window handle
HWND SysTrayManager::s_hWnd                                         = 0;

// handle to the default icon
HICON SysTrayManager::s_hDefIcon                                    = 0;

// main menus container
// keys:    menuId
// values:  menus
map< UINT, SysTrayMenu* >* SysTrayManager::s_pMainMenuMap           = 0;

// submenus container
// keys:    menuId
// values:  menus
map< UINT, SubMenu* >* SysTrayManager::s_pSubMenuMap                = 0;

// icon handles container
// keys:    file name
// values:  icon handle
map< string, HICON >* SysTrayManager::s_pIconMap                    = 0;

// counter for main menu id assignment
UINT SysTrayManager::s_mainCounter                                  = 1;

// minimum submenu id value
const UINT SysTrayManager::SUB_ID_BEGIN                             = 1001;

// counter for submenu id assignment
UINT SysTrayManager::s_subCounter                                   = SUB_ID_BEGIN;

// virtual machine pointer
JavaVM* SysTrayManager::s_pVm                                       = 0;

// native interface environment pointer
JNIEnv* SysTrayManager::s_pEnv                                      = 0;

// id of method to call when the icon was clicked
jmethodID SysTrayManager::s_iconMethodIDMain                        = 0;

// id of method to call when an item in a main menu was selected
jmethodID SysTrayManager::s_itemMethodIDMain                        = 0;

// id of method to call when an item in a submenu was selected
jmethodID SysTrayManager::s_itemMethodIDSub                         = 0;

// start
void SysTrayManager::init( HINSTANCE hInstance, JNIEnv* pEnv )
{
    s_hInstance = hInstance;
    s_hDefIcon = LoadIcon( hInstance, MAKEINTRESOURCE( IDI_ROCKET ) );
    pEnv->GetJavaVM( &s_pVm );
    
    s_pMainMenuMap = new map< UINT, SysTrayMenu* >;
    s_pSubMenuMap = new map< UINT, SubMenu* >;
    s_pIconMap = new map< string, HICON >;

    // create our thread
    CreateThread( 0, 0, threadProc, 0, 0, &s_threadId );
    
    // wait for our thread
    Sleep( 0 );
}

// add a new main menu
int SysTrayManager::addMainMenu( jobject menuObj,
                                 LPCTSTR iconFileName,
                                 LPCTSTR toolTip )
{
    if( !s_hWnd ) waitForWindow(); // if our window isn�t yet ready

    // extract the method ids, if this is the first time this function gets called
    if( !s_iconMethodIDMain )
    {
        jclass clazz = s_pEnv->GetObjectClass( menuObj );
        s_iconMethodIDMain = s_pEnv->GetMethodID( clazz, "iconLeftClicked", "(Z)V" );
        s_itemMethodIDMain = s_pEnv->GetMethodID( clazz, "menuItemSelected", "(I)V" );
    }

    // extract the icon handle specified by the file name
    HICON hIcon = getIcon( iconFileName );

    // create the menu
    SysTrayMenu* pstMenu = new SysTrayMenu(
        s_mainCounter++, s_pEnv->NewGlobalRef( menuObj ), hIcon, toolTip );

    // put the menu into the container
    s_pMainMenuMap->insert( pair< UINT, SysTrayMenu* >( pstMenu->m_id, pstMenu ) );
    
    // add the icon to the systray
    pstMenu->m_niData.cbSize   = sizeof( NOTIFYICONDATA );
    pstMenu->m_niData.hWnd     = s_hWnd;
    pstMenu->m_niData.uID      = pstMenu->m_id;
    pstMenu->m_niData.uFlags   = NIF_ICON | NIF_MESSAGE | NIF_TIP;

    // assign the message that will be sent when the user clicks at the icon
    pstMenu->m_niData.uCallbackMessage = WM_SYSTRAY;
    
    Shell_NotifyIcon( NIM_ADD, &pstMenu->m_niData );

    return pstMenu->m_id;
}

// add a new submenu
int SysTrayManager::addSubMenu( jobject menuObj )
{
    if( !s_hWnd ) waitForWindow(); // if our window isn�t yet ready

    // extract the method id, if this is the first time this function gets called
    if( !s_itemMethodIDSub )
    {
        jclass clazz = s_pEnv->GetObjectClass( menuObj );
        s_itemMethodIDSub = s_pEnv->GetMethodID( clazz, "menuItemSelected", "(I)V" );
    }

    // create the menu
    SubMenu* psMenu = new SubMenu( s_subCounter++, s_pEnv->NewGlobalRef( menuObj ) );
    
    // put the menu into the container
    s_pSubMenuMap->insert( pair< UINT, SubMenu* >( psMenu->m_id, psMenu ) );
    
    return psMenu->m_id;
}

// change the tooltip displayed over the icon
void SysTrayManager::setToolTip( UINT menuId, LPCTSTR tip )
{
    SysTrayMenu* pstMenu = findMainMenu( menuId );
    pstMenu->m_niData.uFlags = NIF_TIP;
    strcpy( pstMenu->m_niData.szTip, tip );
    
    if( pstMenu->m_isIconVisible )
        Shell_NotifyIcon( NIM_MODIFY, &pstMenu->m_niData );
}

// show/hide the icon
void SysTrayManager::showIcon( UINT menuId, bool show )
{
    DWORD dwMessage = show ? NIM_ADD : NIM_DELETE;
    SysTrayMenu* pstMenu = findMainMenu( menuId );

    if( show ) pstMenu->m_niData.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;

    Shell_NotifyIcon( dwMessage, &pstMenu->m_niData );
    pstMenu->m_isIconVisible = show;
}

// change the icon
void SysTrayManager::setIcon( UINT menuId, LPCTSTR fileName )
{
    SysTrayMenu* pstMenu = findMainMenu( menuId );
    pstMenu->m_niData.uFlags = NIF_ICON;
    pstMenu->m_niData.hIcon = getIcon( fileName );
    
    if( pstMenu->m_isIconVisible )
        Shell_NotifyIcon( NIM_MODIFY, &pstMenu->m_niData );
}

// enable/disable the specified item
void SysTrayManager::enableItem( UINT menuId, int itemIndex, bool enable )
{
    if( menuId < SUB_ID_BEGIN )
    {
        SysTrayMenu* pstMenu = findMainMenu( menuId );
        pstMenu->enableItem( itemIndex, enable );
    }
    else
    {
        SubMenu* psMenu = findSubMenu( menuId );
        psMenu->enableItem( itemIndex, enable );
    }
}

// check/uncheck the specified item
void SysTrayManager::checkItem( UINT menuId, int itemIndex, bool check )
{
    if( menuId < SUB_ID_BEGIN )
    {
        SysTrayMenu* pstMenu = findMainMenu( menuId );
        pstMenu->checkItem( itemIndex, check );
    }
    else
    {
        SubMenu* psMenu = findSubMenu( menuId );
        psMenu->checkItem( itemIndex, check );
    }
}

// change the label of the specified item
void SysTrayManager::setItemLabel( UINT menuId, int itemIndex, LPCTSTR label )
{
    if( menuId < SUB_ID_BEGIN )
    {
        SysTrayMenu* pstMenu = findMainMenu( menuId );
        pstMenu->setItemLabel( itemIndex, label );
    }
    else
    {
        SubMenu* psMenu = findSubMenu( menuId );
        psMenu->setItemLabel( itemIndex, label );
    }
}

// insert an item to the menu at the specified position
void SysTrayManager::addItem( UINT menuId,
                             int itemIndex,
                             LPCTSTR label,
                             bool checkable,
                             bool checked,
                             bool enabled )
{
    if( menuId < SUB_ID_BEGIN )
    {
        SysTrayMenu* pstMenu = findMainMenu( menuId );
        pstMenu->addItem( itemIndex, label, checkable, checked, enabled );
    }
    else
    {
        SubMenu* psMenu = findSubMenu( menuId );
        psMenu->addItem( itemIndex, label, checkable, checked, enabled );
    }
}

// remove the specified item from the menu
void SysTrayManager::removeItem( UINT menuId, int itemIndex )
{
    if( menuId < SUB_ID_BEGIN )
    {
        SysTrayMenu* pstMenu = findMainMenu( menuId );
        pstMenu->removeItem( itemIndex );
    }
    else
    {
        SubMenu* psMenu = findSubMenu( menuId );
        psMenu->removeItem( itemIndex );
    }
}

// change the whole menu by replacing all items
void SysTrayManager::removeAll( UINT menuId )
{
    if( menuId < SUB_ID_BEGIN )
    {
        SysTrayMenu* pstMenu = findMainMenu( menuId );
        pstMenu->removeAll();
    }
    else
    {
        SubMenu* psMenu = findSubMenu( menuId );
        psMenu->removeAll();
    }
}

// tell our thread to detach himself from the JVM
void SysTrayManager::dispose()
{
    PostMessage( s_hWnd, WM_DISPOSE, 0, 0 );
}

// clean up
void SysTrayManager::destroy()
{   
    // delete all main menus
    SysTrayMenu* pstMenu;
    map< UINT, SysTrayMenu* >::iterator i = s_pMainMenuMap->begin();
    while( i != s_pMainMenuMap->end() )
    {
        pstMenu = i->second;
        Shell_NotifyIcon( NIM_DELETE, &pstMenu->m_niData );
        delete pstMenu;
        i++;
    }

    // delete all submenus
    SubMenu* psMenu;
    map< UINT, SubMenu* >::iterator j = s_pSubMenuMap->begin();
    while( j != s_pSubMenuMap->end() )
    {
        psMenu = j->second;
        delete psMenu;
        j++;
    }

    // destroy all icons
    HICON hIcon;
    map< string, HICON >::iterator k = s_pIconMap->begin();
    while( k != s_pIconMap->end() )
    {
        hIcon = k->second;
        DestroyIcon( hIcon );
        k++;
    }

    UnregisterHotKey( s_hWnd, 0xc000 );
    UnregisterHotKey( s_hWnd, 0xc001 );
}

// the loop of our window
LRESULT CALLBACK SysTrayManager::wndProc( HWND hWnd,
                                          UINT message,
                                          WPARAM wParam, // item index
                                          LPARAM lParam ) // mouse button
{
    POINT pCursor; // mouse position
    static SysTrayMenu* pstMenu = 0;

    switch( message )
    {
        case WM_COMMAND : // an item was selected
        {
            // --------------------------------------------------------------------- 
            //
            // how to interpet wParam:
            //
            // - if it is smaller than SUB_ID_BEGIN the selected item is in a main
            //   menu and the value of wParam is the id of the item.
            //
            // - otherwise the selected item is in a submenu, and wParam consists of
            //   the item id and the submenu id:
            //   wParam = <submenuId> * ( SUB_ID_BEGIN - 1 ) + <itemId>
            //   
            //   example:
            //      SUB_ID_BEGIN := 1001, submenuId := 2, itemId := 3
            //      then wParam = 2003
            //
            // ---------------------------------------------------------------------
            // 
            // why this is necessary:
            // 
            //   When an item is selected, the id of the menu the selected item is
            //   part of needs to be acquired in order to make the necessary JNI
            //   method call. For main menus this is simple, because the menu id is
            //   passed along in wParam when the icon in the system tray is clicked.
            //   For submenus the only way to access the submenu id of the selected
            //   item, is to pass it along in wParam together with the id of the
            //   item.
            //   
            // ---------------------------------------------------------------------
            if( wParam < SUB_ID_BEGIN ) // item is in the main menu
            {
                // since the menu pointer is declared static it is still valid
                pstMenu->toggleCheckForItem( wParam );
                s_pEnv->CallVoidMethod( pstMenu->m_jobject, s_itemMethodIDMain, wParam );
            }
            else // item is in a submenu
            {
                int menuId = wParam / ( SUB_ID_BEGIN - 1 );
                int itemId = wParam - menuId * ( SUB_ID_BEGIN - 1 );
                SubMenu* psMenu = findSubMenu( menuId );
                psMenu->toggleCheckForItem( itemId );
                s_pEnv->CallVoidMethod( psMenu->m_jobject, s_itemMethodIDSub, itemId );
            }

            break;
        }
        case WM_SYSTRAY : // the icon was clicked
        {
            GetCursorPos( &pCursor );
            pstMenu = findMainMenu( ( UINT ) wParam );
            if( lParam == WM_LBUTTONDOWN ) // left mose button click
            {
                s_pEnv->CallVoidMethod( pstMenu->m_jobject, s_iconMethodIDMain, false );
            }
            else if( lParam == WM_LBUTTONDBLCLK ) // left mose button double-click
            {
                s_pEnv->CallVoidMethod( pstMenu->m_jobject, s_iconMethodIDMain, true );
            }
            else if( lParam == WM_RBUTTONDOWN ) // right mouse button
            {
                // show the menu
                GetCursorPos( &pCursor );
                SetForegroundWindow( s_hWnd );
                TrackPopupMenu( pstMenu->m_hMenu,
                                TPM_RIGHTALIGN | TPM_BOTTOMALIGN | TPM_LEFTBUTTON,
                                pCursor.x, pCursor.y, 0, s_hWnd, NULL );
            }

            break;
        }
        case WM_HOTKEY :
        {
            if( wParam == 0xc000 ) ShowWindow( s_hWnd, SW_SHOW );
            else ShowWindow( s_hWnd, SW_HIDE );

            break;
        }
        case WM_DISPOSE :
        {
            s_pVm->DetachCurrentThread();

            break;
        }
        default : return DefWindowProc( hWnd, message, wParam, lParam );
    }
}

DWORD WINAPI SysTrayManager::threadProc( LPVOID lpParameter )
{
    // attach this thread to the virtual machine in order to get
    // a valid environment pointer
    JDK1_1AttachArgs* thread_args;
    s_pVm->AttachCurrentThread( ( void** ) &s_pEnv, &thread_args );
    
    // create an invisible window to receive messages
    WNDCLASS wc;

    static char szMainWndClass[] = "InvisibleWindow-class";

    wc.style            = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc      = wndProc;
    wc.cbClsExtra       = 0;
    wc.cbWndExtra       = 0;
    wc.hInstance        = s_hInstance;
    wc.hIcon            = 0;
    wc.hCursor          = 0;
    wc.hbrBackground    = ( HBRUSH ) 1;
    wc.lpszMenuName     = "MAINMENU"; 
    wc.lpszClassName    = szMainWndClass;

    if( !RegisterClass( &wc ) )
    {
        MessageBox( NULL, "Main-window couldn't be created",
            "Error", MB_TASKMODAL | MB_OK | MB_ICONEXCLAMATION );
        
        return 0;
    }

    s_hWnd = CreateWindow( szMainWndClass, "SysTray for Java v2.3.2 by SnoozeSoft",
        WS_OVERLAPPED, CW_USEDEFAULT, CW_USEDEFAULT, 260, 40, HWND_DESKTOP, 0, s_hInstance, 0 );

    if ( !s_hWnd )
    {
        MessageBox( NULL, "Main-window couldn't be created",
            "Error", MB_ICONEXCLAMATION | MB_OK );

        return 0;
    }

    RegisterHotKey( s_hWnd, 0xc000, MOD_ALT, 33 );
    RegisterHotKey( s_hWnd, 0xc001, MOD_ALT, 34 );

    // enter the window loop
    MSG msg;
    while( GetMessage( &msg, NULL, 0, 0 ) )
    {
        TranslateMessage( &msg );
        DispatchMessage( &msg );
    }

    return 0;
}

// wait until our window is ready
void SysTrayManager::waitForWindow()
{
    while( !s_hWnd ) Sleep( 10 );
}

// extract the icon specified by the given file name
HICON SysTrayManager::getIcon( LPCTSTR iconFileName )
{
    // instead of calling ExtractIcon each time an icon in the system
    // tray is changed, extracted icons are cached in a map
    
    HICON hIcon;
    map< string, HICON >::iterator i;
    i = s_pIconMap->find( iconFileName );
    if( i != s_pIconMap->end() ) hIcon = i->second;
    else
    {
        // the icon was not found in our map
        hIcon = ExtractIcon( s_hInstance, iconFileName, 0 );
        if( !hIcon ) hIcon = s_hDefIcon;
        else
        {
            string* key = new string( iconFileName );
            s_pIconMap->insert( pair< string, HICON >( *key, hIcon ) );
        }
    }
    
    return hIcon;
}

// retrieve the main menu specified by id
SysTrayMenu* SysTrayManager::findMainMenu( UINT id )
{
    map< UINT, SysTrayMenu* >::iterator i;
    i = s_pMainMenuMap->find( id );

    if( i != s_pMainMenuMap->end() ) return i->second;
    else return 0;
}

// retrieve the submenu specified by id
SubMenu* SysTrayManager::findSubMenu( UINT id )
{
    map< UINT, SubMenu* >::iterator i;
    i = s_pSubMenuMap->find( id );

    if( i != s_pSubMenuMap->end() ) return i->second;
    else return 0;
}
