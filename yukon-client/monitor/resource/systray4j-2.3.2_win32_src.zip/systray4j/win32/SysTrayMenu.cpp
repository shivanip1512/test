/*********************************************************************************
                                  SysTrayMenu.cpp
                                  ---------------
    author               : Tamas Bara
    copyright            : (C) 2002-2003 by SnoozeSoft
    email                : snoozesoft@compuserve.de
 *********************************************************************************/

/*********************************************************************************
 *                                                                               *
 *   This library is free software; you can redistribute it and/or               *
 *   modify it under the terms of the GNU Lesser General Public                  *
 *   License as published by the Free Software Foundation; either                *
 *   version 2.1 of the License, or (at your option) any later version.          *
 *                                                                               *
 *   This library is distributed in the hope that it will be useful,             *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU           *
 *   Lesser General Public License for more details.                             *
 *                                                                               *
 *   You should have received a copy of the GNU Lesser General Public            *
 *   License along with this library; if not, write to the Free Software         *
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA   *
 *                                                                               *
 *********************************************************************************/

// represents a main menu

#include "StdAfx.h"
#include "systraymanager.h"

SysTrayMenu::SysTrayMenu( UINT id,                   // menu id
                          jobject jObject,           // java menu object reference
                          HICON hIcon,               // icon handle
                          LPCTSTR toolTip )          // tooltip
{
    m_id                    = id;
    m_jobject               = jObject;
    m_niData.hIcon          = hIcon;
    m_hMenu                 = CreatePopupMenu();
    m_isIconVisible         = true;

    strcpy( m_niData.szTip, toolTip );
}

SysTrayMenu::~SysTrayMenu()
{
    DestroyMenu( m_hMenu );
}

void SysTrayMenu::addItem( int id, LPCTSTR label, bool checkable, bool checked, bool enabled )
{
    SubMenu* psMenu = 0;
    string temp = label;

    // check whether the label refers to a submenu
    if( temp.find( "#SUB<" ) == 0
            && temp.find( "><" ) != temp.npos
                && temp.rfind( ">" ) == temp.length() - 1 )
    {
        // submenu reference string format:
        //   #SUB<id><label>
        
        // extract the id of the submenu
        int begin = temp.find( "<" ) + 1;
        string sid = temp.substr( begin, temp.find( ">" ) - begin );
        
        // extract the label of the submenu
        begin = temp.find( "><" ) + 2;
        temp = temp.substr( begin, temp.size() - begin - 1 );

        int menuId = atoi( sid.c_str() );
        psMenu = SysTrayManager::findSubMenu( menuId );
    }
    
    MENUITEMINFO miInfo;
    miInfo.cbSize       = sizeof( MENUITEMINFO );
    miInfo.fMask        = MIIM_TYPE;
    miInfo.fType        = strcmp( label, "#SEP" ) ? MFT_STRING : MFT_SEPARATOR;
    miInfo.dwTypeData   = psMenu ? strdup( temp.c_str() ) : strdup( label );
    miInfo.cch          = psMenu ? strlen( temp.c_str() ) : strlen( label );
    
    UINT pos = GetMenuItemCount( m_hMenu ) - id; 
    InsertMenuItem( m_hMenu, pos, TRUE, &miInfo );

    UINT newId = id;
    for( int i = pos; i > -1; i-- )
    {
        miInfo.fMask        = MIIM_ID;
        miInfo.wID          = newId++;

        SetMenuItemInfo( m_hMenu, i, TRUE, &miInfo );
    }

    if( psMenu )
    {
        miInfo.fMask        = MIIM_SUBMENU;
        miInfo.hSubMenu     = psMenu->getMenuHandle();

        SetMenuItemInfo( m_hMenu, 0, TRUE, &miInfo );
    }

    if( checkable )
    {
        m_checkableItems.push_back( id );
        if( checked ) checkItem( id, checked );
    }

    if( !enabled ) enableItem( id, enabled );
}

void SysTrayMenu::enableItem( int id, bool enable )
{
    UINT uEnable = enable ? ( MF_BYCOMMAND | MF_ENABLED ) : ( MF_BYCOMMAND | MF_GRAYED );
    EnableMenuItem( m_hMenu, id, uEnable );
}

void SysTrayMenu::toggleCheckForItem( int id )
{
    // check whether the specified item is checkable
    list< int >::iterator iter = m_checkableItems.begin();
    while( iter != m_checkableItems.end() )
    {
        if( *iter == id ) break;
        iter++;
    }
    
    if( iter != m_checkableItems.end() )
    {
        // toggle check mark
        UINT uCheck = GetMenuState( m_hMenu, id, MF_BYCOMMAND );

        uCheck = ( uCheck & MF_CHECKED ) ? MF_UNCHECKED : MF_CHECKED;
        CheckMenuItem( m_hMenu, id, uCheck );
    }
}

void SysTrayMenu::checkItem( int id, bool check )
{
    UINT uCheck = check ? MF_CHECKED : MF_UNCHECKED;
    CheckMenuItem( m_hMenu, id, uCheck );
}

void SysTrayMenu::setItemLabel( int id, LPCTSTR label )
{
    MENUITEMINFO miInfo;
    miInfo.cbSize       = sizeof( MENUITEMINFO );
    miInfo.fMask        = MIIM_TYPE;
    miInfo.fType        = MFT_STRING;
    miInfo.dwTypeData   = strdup( label );
    miInfo.cch          = strlen( label );
    
    SetMenuItemInfo( m_hMenu, id, FALSE, &miInfo );
}

void SysTrayMenu::removeItem( int id )
{
    MENUITEMINFO miInfo;
    miInfo.cbSize = sizeof( MENUITEMINFO );
    
    RemoveMenu( m_hMenu, id, MF_BYCOMMAND );

    UINT newId = id;
    UINT pos = GetMenuItemCount( m_hMenu ) - id - 1;
    for( int i = pos; i > -1; i-- )
    {
        miInfo.fMask        = MIIM_ID;
        miInfo.wID          = newId++;

        SetMenuItemInfo( m_hMenu, i, TRUE, &miInfo );
    }
}

void SysTrayMenu::removeAll()
{
    MENUITEMINFO miInfo;
    miInfo.cbSize = sizeof( MENUITEMINFO );
    
    int count = GetMenuItemCount( m_hMenu );
    for( int i = 0; i < count; i++ )
        RemoveMenu( m_hMenu, 0, MF_BYPOSITION );

    m_checkableItems.clear();
}
