/*********************************************************************************
                                  SysTrayManager.h
                                  ----------------
    author               : Tamas Bara
    copyright            : (C) 2002-2003 by SnoozeSoft
    email                : snoozesoft@compuserve.de
 *********************************************************************************/

/*********************************************************************************
 *                                                                               *
 *   This library is free software; you can redistribute it and/or               *
 *   modify it under the terms of the GNU Lesser General Public                  *
 *   License as published by the Free Software Foundation; either                *
 *   version 2.1 of the License, or (at your option) any later version.          *
 *                                                                               *
 *   This library is distributed in the hope that it will be useful,             *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of              *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU           *
 *   Lesser General Public License for more details.                             *
 *                                                                               *
 *   You should have received a copy of the GNU Lesser General Public            *
 *   License along with this library; if not, write to the Free Software         *
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA   *
 *                                                                               *
 *********************************************************************************/

#pragma once

#include "stdafx.h"
#include "systraymenu.h"
#include "submenu.h"

class SysTrayManager
{
    public :

        enum
        {
            // message sent to our window when the icon was clicked
            WM_SYSTRAY = WM_USER,

            // message sent to our window when our thread should be detached
            // from the JVM
            WM_DISPOSE = WM_USER + 1
        };

    public :

        static const UINT SUB_ID_BEGIN;
        
        static void init( HINSTANCE hInstance, JNIEnv* pEnv );
        
        static int addMainMenu( jobject menuObj,
                                LPCTSTR iconFileName,
                                LPCTSTR toolTip );

        static int addSubMenu( jobject menuObj );
        
        static void setToolTip( UINT menuId, LPCTSTR tip );
        
        static void showIcon( UINT menuId, bool show );
        static void setIcon( UINT menuId, LPCTSTR fileName );
        
        static void enableItem( UINT menuId, int itemIndex, bool enable );
        static void checkItem( UINT menuId, int itemIndex, bool check );
        static void setItemLabel( UINT menuId, int itemIndex, LPCTSTR label );
        
        static void addItem( UINT menuId,
                             int itemIndex,
                             LPCTSTR label,
                             bool checkable,
                             bool checked,
                             bool enabled );
        
        static void removeItem( UINT menuId, int itemIndex );
        static void removeAll( UINT menuId );

        static void dispose();

        static SubMenu* findSubMenu( UINT );
        
        static void destroy();

    private :

        static DWORD                        s_threadId;
        static HINSTANCE                    s_hInstance;
        static HWND                         s_hWnd;
        static HICON                        s_hDefIcon;
        static map< UINT, SysTrayMenu* >*   s_pMainMenuMap;
        static map< UINT, SubMenu* >*       s_pSubMenuMap;
        static map< string, HICON >*        s_pIconMap;
        static UINT                         s_mainCounter;
        static UINT                         s_subCounter;
        
        static JavaVM*                      s_pVm;
        static JNIEnv*                      s_pEnv;
        static jmethodID                    s_iconMethodIDMain;
        static jmethodID                    s_itemMethodIDMain;
        static jmethodID                    s_itemMethodIDSub;

        static LRESULT CALLBACK wndProc( HWND, UINT, WPARAM, LPARAM );
        static DWORD WINAPI threadProc( LPVOID );
        static void waitForWindow();
        static HICON getIcon( LPCTSTR );
        static SysTrayMenu* findMainMenu( UINT );
};
